# tipos-de-css
Exercício sobre os tipos de CSS: inline, embutido e externo.
